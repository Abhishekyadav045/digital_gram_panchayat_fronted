import React from 'react'
import "./complaint.css"

export const Complaints = () => {
    return (
        <>
            <meta charSet="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Complaint Portal | Digital Gram Panchayat</title>
            <link rel="stylesheet" href="complaint.css" />
            {/* Bootstrap */}
            <link
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                rel="stylesheet"
            />
            <section className="complaint-section">
                <div className="container">
                    <div className="heading">
                        <h1>Complaint Portal</h1>
                        <p>
                            Register your complaint online and help us improve your village. Your
                            complaint will be forwarded to the concerned department.
                        </p>
                    </div>
                    <div className="row">
                        {/* Complaint Form */}
                        <div className="col-lg-8">
                            <div className="card shadow-lg border-0 p-4">
                                <h3 className="text-success mb-4">Register Complaint</h3>
                                <form>
                                    <div className="row">
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label">Full Name</label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Enter your name"
                                            />
                                        </div>
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label">Mobile Number</label>
                                            <input
                                                type="tel"
                                                className="form-control"
                                                placeholder="Enter mobile number"
                                            />
                                        </div>
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Email Address</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            placeholder="Enter email"
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Village Name</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Enter village name"
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Complaint Category</label>
                                        <select className="form-select">
                                            <option selected="">Select Category</option>
                                            <option>Road</option>
                                            <option>Water Supply</option>
                                            <option>Electricity</option>
                                            <option>Drainage</option>
                                            <option>Sanitation</option>
                                            <option>Street Light</option>
                                            <option>Government Scheme</option>
                                            <option>Others</option>
                                        </select>
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Complaint Details</label>
                                        <textarea
                                            rows={5}
                                            className="form-control"
                                            placeholder="Describe your complaint..."
                                            defaultValue={""}
                                        />
                                    </div>
                                    <div className="mb-4">
                                        <label className="form-label">Upload Image (Optional)</label>
                                        <input type="file" className="form-control" />
                                    </div>
                                    <button className="btn btn-success px-5">Submit Complaint</button>
                                </form>
                            </div>
                        </div>
                        {/* Right Side */}
                        <div className="col-lg-4">
                            <div className="info-card">
                                <h4>Complaint Guidelines</h4>
                                <ul>
                                    <li>✔ Enter correct personal details.</li>
                                    <li>✔ Select the correct complaint category.</li>
                                    <li>✔ Attach an image if available.</li>
                                    <li>✔ Your complaint ID will be generated after submission.</li>
                                    <li>✔ Track complaint status online.</li>
                                </ul>
                            </div>
                            <div className="info-card mt-4">
                                <h4>Emergency Contacts</h4>
                                <p>📞 Panchayat Office : 1800-123-456</p>
                                <p>🚓 Police : 112</p>
                                <p>🚑 Ambulance : 108</p>
                                <p>🔥 Fire : 101</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    )
}
