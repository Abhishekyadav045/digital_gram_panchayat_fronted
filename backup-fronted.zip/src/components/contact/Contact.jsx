import React from 'react'
import "./contact.css"

export const Contact = () => {
    return (
        <>
            <meta charSet="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Contact Us | Digital Gram Panchayat</title>
            <link rel="stylesheet" href="contact.css" />
            {/* Bootstrap */}
            <link
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                rel="stylesheet"
            />
            {/* Bootstrap Icons */}
            <link
                rel="stylesheet"
                href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
            />
            <section className="contact-section">
                <div className="container">
                    <div className="heading">
                        <h1>Contact Us</h1>
                        <p>
                            We'd love to hear from you. Contact the Gram Panchayat Office for any
                            assistance, suggestions, or complaints.
                        </p>
                    </div>
                    <div className="row">
                        {/* Contact Form */}
                        <div className="col-lg-7">
                            <div className="contact-card">
                                <h3 className="text-success mb-4">Send us a Message</h3>
                                <form>
                                    <div className="row">
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label">Full Name</label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Enter your name"
                                            />
                                        </div>
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label">Mobile Number</label>
                                            <input
                                                type="tel"
                                                className="form-control"
                                                placeholder="Enter mobile number"
                                            />
                                        </div>
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Email Address</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            placeholder="Enter email"
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Village</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Enter Village"
                                        />
                                    </div>
                                    <div className="mb-4">
                                        <label className="form-label">Message</label>
                                        <textarea
                                            rows={5}
                                            className="form-control"
                                            placeholder="Write your message..."
                                            defaultValue={""}
                                        />
                                    </div>
                                    <button className="btn btn-success px-5">Send Message</button>
                                </form>
                            </div>
                        </div>
                        {/* Contact Information */}
                        <div className="col-lg-5">
                            <div className="info-card">
                                <h3>Contact Information</h3>
                                <p>
                                    <i className="bi bi-geo-alt-fill" />
                                    Gram Panchayat Office,
                                    <br />
                                    Village Rampur, Block XYZ,
                                    <br />
                                    District Lucknow, Uttar Pradesh
                                </p>
                                <p>
                                    <i className="bi bi-telephone-fill" />
                                    +91 9302380687
                                </p>
                                <p>
                                    <i className="bi bi-envelope-fill" />
                                    support@digitalgram.in
                                </p>
                                <p>
                                    <i className="bi bi-clock-fill" />
                                    Monday - Saturday <br />
                                    10:00 AM - 5:00 PM
                                </p>
                            </div>
                            <div className="info-card mt-4">
                                <h3>Emergency Numbers</h3>
                                <p>🚓 Police : 112</p>
                                <p>🚑 Ambulance : 108</p>
                                <p>🔥 Fire Brigade : 101</p>
                                <p>☎ Panchayat Helpline : 1800-123-456</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    )
}
