import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export const Header = () => {
    const navigate = useNavigate();

    const [isLoggedIn, setIsLoggedIn] = useState(false);

    // Check login status
    useEffect(() => {
        const checkLogin = () => {
            const token = localStorage.getItem("authToken");
            setIsLoggedIn(!!token);
        };

        checkLogin();

        window.addEventListener("storage", checkLogin);

        return () => {
            window.removeEventListener("storage", checkLogin);
        };
    }, []);

    // Logout
    const handleLogout = () => {
        localStorage.removeItem("authToken");
        setIsLoggedIn(false);
        toast.success("Logout Successful!");

        setTimeout(() => {
            navigate("/login");
            window.location.reload();
        }, 1000);
    };

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-success shadow sticky-top">
            <div className="container">

                {/* Logo */}
                <Link
                    className="navbar-brand d-flex align-items-center"
                    to="/"
                >
                    <img
                        src="/logo.png"
                        alt="Logo"
                        width="50"
                        height="50"
                        className="rounded-circle me-2 bg-white p-1"
                    />

                    <div>
                        <h5 className="mb-0 fw-bold">
                            Digital Gram Panchayat
                        </h5>

                        <small className="text-light">
                            Smart Village • Digital India
                        </small>
                    </div>
                </Link>

                {/* Toggle Button */}
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarContent"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>

                {/* Navbar */}
                <div
                    className="collapse navbar-collapse"
                    id="navbarContent"
                >
                    <ul className="navbar-nav ms-auto align-items-lg-center">

                        <li className="nav-item">
                            <Link className="nav-link" to="/">
                                Home
                            </Link>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" to="/citizen-services">
                                Services
                            </Link>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" to="/government-schemes">
                                Government Schemes
                            </Link>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" to="/certificate">
                                Certificates
                            </Link>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" to="/complaints">
                                Complaints
                            </Link>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" to="/contact">
                                Contact
                            </Link>
                        </li>

                        <li className="nav-item ms-lg-3">
                            {isLoggedIn ? (


                                <div className="dropdown">
                                    <button
                                        className="btn btn-danger dropdown-toggle rounded-pill px-4"
                                        type="button"
                                        data-bs-toggle="dropdown"
                                        aria-expanded="false"
                                    >
                                        My Account
                                    </button>

                                    <ul className="dropdown-menu dropdown-menu-end shadow">
                                        <li>
                                            <Link className="dropdown-item" to="/add-blog">
                                                <i className="bi bi-plus-circle me-2"></i>
                                                Add Blog
                                            </Link>
                                        </li>

                                        <li>
                                            <hr className="dropdown-divider" />
                                        </li>

                                        <li>
                                            <button
                                                className="dropdown-item text-danger"
                                                onClick={handleLogout}
                                            >
                                                <i className="bi bi-box-arrow-right me-2"></i>
                                                Logout
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            ) : (
                                <div className="d-flex gap-2">
                                    <Link
                                        to="/login"
                                        className="btn btn-warning fw-bold px-4"
                                    >
                                        Login
                                    </Link>

                                    <Link
                                        to="/sign-up"
                                        className="btn btn-info fw-bold px-4"
                                    >
                                        Sign Up
                                    </Link>
                                </div>
                            )}
                        </li>

                    </ul>
                </div>

            </div>
        </nav>
    )
}