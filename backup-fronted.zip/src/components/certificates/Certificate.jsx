import React from 'react'
import "./certificate.css"
import { Link } from 'react-router-dom'

export const Certificate = () => {
    return (
        <>
            <meta charSet="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Certificate Services | Digital Gram Panchayat</title>
            <link rel="stylesheet" href="certificate.css" />
            {/* Bootstrap */}
            <link
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                rel="stylesheet"
            />
            {/* Bootstrap Icons */}
            <link
                rel="stylesheet"
                href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
            />
            <section className="certificate-section">
                <div className="container">
                    <div className="heading">
                        <h1>Certificate Services</h1>
                        <p>
                            Apply online for various government certificates quickly and securely
                            through the Digital Gram Panchayat Portal.
                        </p>
                    </div>
                    <div className="row g-4">
                        {/* Birth Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">👶</div>
                                <h4>Birth Certificate</h4>
                                <p>Register and apply for a Birth Certificate online.</p>
                                <a href="./birth_certificate" className="btn btn-success">
                                    Apply
                                </a>
                            </div>
                        </div>
                        {/* Death Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">📄</div>
                                <h4>Death Certificate</h4>
                                <p>Apply for a Death Certificate issued by the Gram Panchayat.</p>
                                <a href="./death_certificate" className="btn btn-success">
                                    Apply
                                </a>
                            </div>
                        </div>
                        {/* Income Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">💰</div>
                                <h4>Income Certificate</h4>
                                <p>Apply online for an Income Certificate for official purposes.</p>
                                <Link to="https://edistrict.up.gov.in/edistrictup/" target="_blank" className="btn btn-success">
                                    Apply
                                </Link>
                            </div>
                        </div>
                        {/* Residence Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">🏠</div>
                                <h4>Residence Certificate</h4>
                                <p>Get your Residence/Domicile Certificate online.</p>
                                <Link href="https://edistrict.up.gov.in/edistrictup/" target="_blank" className="btn btn-success">
                                    Apply
                                </Link>
                            </div>
                        </div>
                        {/* Caste Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">🪪</div>
                                <h4>Caste Certificate</h4>
                                <p>Apply for SC/ST/OBC Caste Certificate.</p>
                                <Link to="https://edistrict.up.gov.in/edistrictup/" target="_blank" className=" btn btn-success">
                                    Apply
                                </Link>
                            </div>
                        </div>
                        {/* Character Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">📑</div>
                                <h4>Character Certificate</h4>
                                <p>
                                    Apply for Character Certificate required for education and jobs.
                                </p>
                                <a href="#" className="btn btn-success">
                                    Apply
                                </a>
                            </div>
                        </div>
                        {/* Marriage Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">💍</div>
                                <h4>Marriage Certificate</h4>
                                <p>Apply for an official Marriage Registration Certificate.</p>
                                <a href="#" className="btn btn-success">
                                    Apply
                                </a>
                            </div>
                        </div>
                        {/* Disability Certificate */}
                        <div className="col-md-6 col-lg-3">
                            <div className="certificate-card">
                                <div className="icon">♿</div>
                                <h4>Disability Certificate</h4>
                                <p>Apply for a Disability Certificate for government benefits.</p>
                                <a href="#" className="btn btn-success">
                                    Apply
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section >
        </>

    )
}
