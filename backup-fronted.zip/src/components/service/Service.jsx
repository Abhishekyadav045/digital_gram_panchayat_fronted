import React from 'react'
import { Link } from 'react-router-dom';



export const categories = [
    {
        icon: "📄",
        title: "Certificates",
        description: "Birth, Death, Residence, Income and other certificates.",
        path: "/certificate",
    },
    {
        icon: "🏛",
        title: "Government Schemes",
        description: "Apply for PMAY, PM-Kisan, Pension and other schemes.",
        path: "/certificate",
    },
    {
        icon: "📝",
        title: "Complaints",
        description: "Register complaints and track their status online.",
        path: "/complaints",
    },
    {
        icon: "🏥",
        title: "Health",
        description: "Health camps, vaccination, PHC appointments and more.",
        path: "/health",
    },
    {
        icon: "🌾",
        title: "Agriculture",
        description: "Crop advisory, subsidies, irrigation and soil testing.",
        path: "/agriculture",
    },
    {
        icon: "💼",
        title: "Employment",
        description: "MGNREGA, local jobs and skill development programs.",
        path: "/employment",
    },
];

export const Services = () => {
    return (
        <div className="container py-5">

            <div className="text-center mb-5">
                <h1 className="fw-bold text-success">
                    Citizen Services
                </h1>

                <p className="text-muted">
                    Select a service category to continue.
                </p>
            </div>

            <div className="row g-4">

                {categories.map((item, index) => (
                    <div className="col-md-6 col-lg-4" key={index}>

                        <div className="card shadow border-0 h-100 text-center p-4 rounded-4">

                            <div
                                className="mx-auto mb-3"
                                style={{
                                    width: "80px",
                                    height: "80px",
                                    background: "#198754",
                                    color: "white",
                                    borderRadius: "50%",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    fontSize: "35px",
                                }}
                            >
                                {item.icon}
                            </div>

                            <h4 className="fw-bold">{item.title}</h4>

                            <p className="text-muted">
                                {item.description}
                            </p>

                            <Link
                                to={item.path}
                                className="btn btn-success mt-auto"
                            >
                                Explore →
                            </Link>

                        </div>

                    </div>
                ))}

            </div>

        </div>
    );
}