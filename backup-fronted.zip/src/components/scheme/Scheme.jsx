import React from 'react'
import "./scheme.css"
import { Link } from 'react-router-dom'


export const Scheme = () => {
    return (
        <>
            <meta charSet="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Government Schemes | Digital Gram Panchayat</title>
            <link rel="stylesheet" href="government-schemes.css" />
            {/* Bootstrap */}
            <link
                href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                rel="stylesheet"
            />
            {/* Bootstrap Icons */}
            <link
                rel="stylesheet"
                href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
            />
            <section className="scheme-section">
                <div className="container">
                    <div className="heading">
                        <h1>Government Schemes</h1>
                        <p>
                            Explore various Central and State Government welfare schemes available
                            for citizens of the Gram Panchayat.
                        </p>
                    </div>
                    <div className="row g-4">
                        {/* PM Awas */}
                        <div className="col-md-6 col-lg-4">
                            <div className="scheme-card">
                                <div className="icon">
                                    <i className="bi bi-house-door-fill" />
                                </div>
                                <h3>PM Awas Yojana</h3>
                                <p>
                                    Financial assistance for construction of permanent houses for
                                    eligible rural families.
                                </p>
                                <Link to="https://pmayg.dord.gov.in/netiayHome/Home.aspx" target="_blank" className="btn btn-success">
                                    Apply Now
                                </Link>
                            </div>
                        </div>
                        {/* PM Kisan */}
                        <div className="col-md-6 col-lg-4">
                            <div className="scheme-card">
                                <div className="icon">
                                    <i className="bi bi-tree-fill" />
                                </div>
                                <h3>PM Kisan Samman Nidhi</h3>
                                <p>₹6,000 annual financial support to eligible farmers.</p>
                                <Link to="https://pmkisan.gov.in/" target="_blank" className="btn btn-success">
                                    Apply Now
                                </Link>
                            </div>
                        </div>
                        {/* Ayushman */}
                        <div className="col-md-6 col-lg-4">
                            <div className="scheme-card">
                                <div className="icon">
                                    <i className="bi bi-heart-pulse-fill" />
                                </div>
                                <h3>Ayushman Bharat</h3>
                                <p>
                                    Free health insurance coverage up to ₹5 lakh for eligible
                                    families.
                                </p>
                                <Link to="https://pmjay.gov.in/" target="_blank" className="btn btn-success">
                                    Apply Now
                                </Link>
                            </div>
                        </div>
                        {/* MGNREGA */}
                        <div className="col-md-6 col-lg-4">
                            <div className="scheme-card">
                                <div className="icon">
                                    <i className="bi bi-people-fill" />
                                </div>
                                <h3>MGNREGA</h3>
                                <p>Provides guaranteed wage employment to rural households.</p>
                                <Link to="https://nrega.dord.gov.in/MGNREGA_new/Nrega_home.aspx" target="_blank" className="btn btn-success">
                                    Apply Now
                                </Link>
                            </div>
                        </div>
                        {/* Swachh Bharat */}
                        <div className="col-md-6 col-lg-4">
                            <div className="scheme-card">
                                <div className="icon">
                                    <i className="bi bi-recycle" />
                                </div>
                                <h3>Swachh Bharat Mission</h3>
                                <p>
                                    Promotes sanitation, cleanliness and construction of household
                                    toilets.
                                </p>
                                <Link to="https://swachhbharatmission.ddws.gov.in/" target="_blank" className="btn btn-success">
                                    Apply Now
                                </Link>
                            </div>
                        </div>
                        {/* Ujjwala */}
                        <div className="col-md-6 col-lg-4">
                            <div className="scheme-card">
                                <div className="icon">
                                    <i className="bi bi-fire" />
                                </div>
                                <h3>PM Ujjwala Yojana</h3>
                                <p>
                                    Free LPG gas connections for eligible women from poor households.
                                </p>
                                <Link to="https://www.pmuy.gov.in/index.aspx" target="_blank" className="btn btn-success">
                                    Apply Now
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    )
}
