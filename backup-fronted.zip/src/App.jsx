
import './App.css'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Header } from './components/header/Header.jsx';
import { Footer } from './components/footer/Footer.jsx';
import { Dashboard } from './components/home/Dashboard.jsx';
import { Services } from './components/service/Service.jsx';
import { Scheme } from './components/scheme/Scheme.jsx';
import { Certificate } from './components/certificates/Certificate.jsx';
import { Complaints } from './components/complaints/Complaints.jsx';
import { Contact } from './components/contact/Contact.jsx';
import { Signup } from './components/signup/Sign-up.jsx';
import { Login } from './components/login/Login.jsx';

import { Birth_certificate } from './components/birth_certificate/Birth_certificate.jsx';
import { Death_certificate } from './components/death_certificate/Death_certificate.jsx';










function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Routes>

          <Route path="/" element={< Dashboard />} />
          <Route path="citizen-services" element={< Services />} />
          <Route path="government-schemes" element={<Scheme />} />
          <Route path="certificate" element={<Certificate />} />
          <Route path="complaints" element={<Complaints />} />
          <Route path="services" element={< Services />} />
          <Route path="contact" element={<Contact />} />
          <Route path="sign-up" element={<Signup />} />
          <Route path="login" element={< Login />} />
          <Route path="birth_certificate" element={< Birth_certificate />} />
          <Route path="death_certificate" element={<  Death_certificate />} />






        </Routes>
        <Footer />
      </BrowserRouter>

    </>
  )
}

export default App
